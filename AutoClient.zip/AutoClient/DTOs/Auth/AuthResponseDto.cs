﻿namespace AutoClient.DTOs.Auth;

public class AuthResponseDto
{
    public string Token { get; set; }
    public string WorkshopName { get; set; }
    public string Subdomain { get; set; }
}
