﻿namespace AutoClient.DTOs.ServiceTypes;

public class CreateServiceTypeDto
{
    public string ServiceTypeName { get; set; } = string.Empty;
}
